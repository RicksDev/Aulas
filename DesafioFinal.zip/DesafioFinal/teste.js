const teste = document.getElementById('teste')

teste.addEventListener('click', ()=>{
    window.open('https://www.instagram.com/ricardo.filho04/', '_blank');
})